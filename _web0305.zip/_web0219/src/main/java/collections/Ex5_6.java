package collections;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import dto.Board;

public class Ex5_6 {

	public static void main(String[] args) {
		List<Board> list1 = new ArrayList<>(); // 5번 답
		Map<String, Integer> map1 = new HashMap<>();  // 6번 답
	}

}
