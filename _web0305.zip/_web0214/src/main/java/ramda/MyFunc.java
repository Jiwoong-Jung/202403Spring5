package ramda;

public interface MyFunc {
	void method(int x);
//	void bbb();
}
