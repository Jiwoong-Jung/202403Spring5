package ramda;

@FunctionalInterface
public interface MyFunctionalInterface {
	int method(int x, int y);

}
