package ramda;


@FunctionalInterface
public interface MyFunc {
	void aaa();
}
